#! /bin/bash

make && ./proj3
